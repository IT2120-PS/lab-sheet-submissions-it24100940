getwd()
setwd("C:/Users/it24100940/Documents")

